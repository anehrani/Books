//Author: Yusuf Sahillioglu
//Aim: Implementation of my Scale-Adaptive ICP paper. Once ICP finds rotation, I solve for scale and translation jointly, hence scale-adaptive ICP


//#include <time.h>
/*#include <windows.h> //for get_time()
inline double get_time()
{
	LARGE_INTEGER t, frequency;
	QueryPerformanceCounter(&t);
	QueryPerformanceFrequency(&frequency);
	return (double)t.QuadPart/(double)frequency.QuadPart;
}*/

#include "Mesh.h"

int main(int argc, char ** argv)
{
	//ScaleAdaptiveICP <cloud1-transforming> <cloud2-fixed> <ScaleAdaptive: 1 or Classical: 0> <1-to-1-start: 1 or many-to-1: 0> <nMaxIterations> <minDisplacement: optional -- default 0.001>
	//ScaleAdaptiveICP homer-top-downscaled-rotated homer 1 1 200

	int nMaxIters; //max # of Scale-Adaptive (or Classical) ICP iterations		
	bool scaleAdaptiveICP, oneToOneStart;
	char fName[250], fName2[250],
		 fNameExt[250], fNameExt2[250], ofNameExt[250];
	float minDisplacement = 0.001f;
	if (argc == 6 || argc == 7)
	{
		cout << argv[1];
		sprintf_s(fName, sizeof(fName), argv[1]);
		sprintf_s(fName2, sizeof(fName), argv[2]);
		scaleAdaptiveICP = atoi(argv[3]) == 1;
		oneToOneStart = atoi(argv[4]) == 1;
		nMaxIters = atoi(argv[5]);
		if (argc == 7)
			minDisplacement = (float) atof(argv[6]);
	}
	else
	{
		cout << "6 or 7 arguments must have been provided (you did " << argc << "):\n" <<
			    "ScaleAdaptiveICP <cloud1-transforming> <cloud2-fixed> <ScaleAdaptive: 1 or Classical: 0> <1-to-1-start: 1 or many-to-1: 0> <nMaxIterations> <minDisplacement: optional -- default 0.001>\n";
		exit(0);
	}

	//meshes; they're indeed pure point clouds but this name remained from an old project so let's keep it that way
	Mesh* mesh1 = new Mesh(), * mesh2 = new Mesh();
	
	//load point clouds as mesh vertices
/*	int inputType = 3; //1: face, 2: bunny, 3: homer, 4: fourlegged, 5: hybridface
	if (inputType == 1)
	{
		sprintf_s(fName, sizeof(fName), "face-top-downscaled"); //partial mesh1 (re-scaled)				ICP-FAILS		SICP-WORKS_1to1false
		sprintf_s(fName, sizeof(fName), "face-top-rotated"); //partial mesh1 (no re-scaling)			ICP-WORKS		SICP-WORKS_perfCorrMode

		sprintf_s(fName, sizeof(fName), "face-top-upscaled-rotated"); //partial mesh1 (re-scaled)		ICP-FAILS		SICP-WORKS_1to1false
		sprintf_s(fName, sizeof(fName), "face-top-upscaled-rotated2"); //partial mesh1 (re-scaled)		ICP-FAILS		SICP-WORKS_1to1false
		sprintf_s(fName, sizeof(fName), "face-bottom-upscaled-rotated"); //partial mesh1 (re-scaled)	ICP-FAILS		SICP-WORKS_1to1false	SICP-FAILS_perfCorrMode (recall i-i grd-truth may not always exist; perfCorrMode fails then)
		sprintf_s(fName, sizeof(fName), "face-bottom-upscaled-rotated1"); //partial mesh1 (re-scaled)	ICP-FAILS		SICP-WORKS_1to1false
		sprintf_s(fName, sizeof(fName), "face-bottom-upscaled-rotated2"); //partial mesh1 (re-scaled)	ICP-FAILS		SICP-WORKS (1to1false mode fails here so 1to1 is important)
		sprintf_s(fName, sizeof(fName), "face-bottom-upscaled-rotated3"); //partial mesh1 (re-scaled)	ICP-FAILS		SICP-WORKS (1to1false mode fails here so 1to1 is important)

		sprintf_s(fName, sizeof(fName), "face-top-upscaled"); //partial mesh1 (re-scaled)				ICP-FAILS		SICP-WORKS_1to1false
		sprintf_s(fName, sizeof(fName), "face-downscaled-rotated"); //complete mesh1 (re-scaled)		ICP-FAILS		SICP-WORKS_perfCorrMode
		sprintf_s(fName, sizeof(fName), "face-rotated"); //complete mesh1	(no re-scaling)				ICP-WORKS		SICP-WORKS_perfCorrMode	
	}
	else if (inputType == 2)
	{
		sprintf_s(fName, sizeof(fName), "bunny-top-rotated"); //partial mesh1 (no-rescaling)				ICP-WORKS		SICP-WORKS
		sprintf_s(fName, sizeof(fName), "bunny-left-upscaled-rotated"); //partial mesh1 (re-scaled)		ICP-FAILS		SICP-WORKS
		sprintf_s(fName, sizeof(fName), "bunny-left-downscaled-rotated"); //partial mesh1 (re-scaled)	ICP-FAILS		SICP-WORKS
		sprintf_s(fName, sizeof(fName), "bunny-downscaled-rotated"); //complete mesh1 (re-scaled)		ICP-FAILS		SICP-WORKS
	}
	else if (inputType == 3)
	{
		sprintf_s(fName, sizeof(fName), "homer-downscaled-rotated"); //complete mesh1 (re-scaled)		ICP-FAILS		SICP-WORKS
		sprintf_s(fName, sizeof(fName), "homer-downscaled-rotated2"); //complete mesh1 (re-scaled)		ICP-FAILS		SICP-WORKS
		sprintf_s(fName, sizeof(fName), "homer-downscaled-rotated3"); //complete mesh1 (re-scaled)		ICP-FAILS		SICP-WORKS
		sprintf_s(fName, sizeof(fName), "homer-top-downscaled-rotated"); //partial mesh1 (re-scaled)	ICP-FAILS		SICP-WORKS
		sprintf_s(fName, sizeof(fName), "homer-left-downscaled-rotated"); //partial mesh1 (re-scaled)	ICP-FAILS		SICP-WORKS
		sprintf_s(fName, sizeof(fName), "homer-right-downscaled-rotated"); //partial mesh1 (re-scaled)	ICP-FAILS		SICP-WORKS
		sprintf_s(fName, sizeof(fName), "homer-top-upscaled-rotated"); //partial mesh1 (re-scaled)		ICP-FAILS		SICP-WORKS
	}
	else if (inputType == 4)
	{
		sprintf_s(fName, sizeof(fName), "cat-reference"); //complete mesh1 (no-rescaling)				ICP-FAILS		SICP-WORKS
		sprintf_s(fName, sizeof(fName), "camel-reference"); //complete mesh1 (no-rescaling)				ICP-FAILS		SICP-WORKS
	}
	else if (inputType == 5)
	{
		sprintf_s(fName, sizeof(fName), "cry");
		sprintf_s(fName, sizeof(fName), "face");
	}
	else
	{
		cout << "undefined input type\n";
		exit(0);
	}*/
	//point cloud # 1
	sprintf_s(fNameExt, sizeof(fNameExt), "input\\%s.xyz", fName);
	mesh1->loadPnt(fNameExt);

	//point cloud # 2
/*	if (inputType == 1)
		mesh2->loadPnt("input\\face.xyz");
	else if (inputType == 2)
		mesh2->loadPnt("input\\bunny.xyz");
	else if (inputType == 3)
		mesh2->loadPnt("input\\homer.xyz");
	else if (inputType == 4)
		mesh2->loadPnt("input\\lion-reference.xyz");
	else if (inputType == 5)
		mesh2->loadPnt("input\\surprise-upscaled-rotated.xyz");//-downscaled-rotated.xyz");
	else
	{
		cout << "undefined input type\n";
		exit(0);
	}*/
	sprintf_s(fNameExt2, sizeof(fNameExt2), "input\\%s.xyz", fName2);
	mesh2->loadPnt(fNameExt2);

	//transform point cloud # 1 so that it aligns with point cloud # 2
//	double start_time = get_time();
	mesh1->ICP(mesh2, scaleAdaptiveICP, nMaxIters, oneToOneStart, minDisplacement);
////	mesh1->ICPRansac(mesh2, true);
//	cout << "========> " << get_time()-start_time << " seconds passed (includes sampling time)\n";

	//write resulting pointset to file
	sprintf_s(ofNameExt, sizeof(ofNameExt), "output\\%s_aligned%s.xyz", fName, (scaleAdaptiveICP ? "" : "_classicalICP"));
	mesh1->resultToFile(ofNameExt);

	return 0;
}
