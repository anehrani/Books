#include "Mesh.h"

/* kd-tree is not currently in use; this affects running time drastically for large inputs; so make this ready later
//////////////// kd-tree stuff ////////////////////
//from rosettacode.org/wiki/K-d_tree which is based on 'An intoductory tutorial on kd-trees' by Andrew W. Moore, Carnegie Mellon University.
//Using a Quickselectesque median algorithm. Compared to unbalanced trees (random insertion), it takes slightly longer (maybe
//half a second or so) to construct a million-node tree, though average look up visits about 1/3 fewer nodes.
//note that my old kdtree.c and kdtree.h are also fine except they unexpectedly^ exit'ed in this project; they also dont use median so unbalanced/slower
//^ maby i should have delete'd resultSet after each query; not sure; not checked
#define MAX_DIM 3
struct kd_node_t{
    double x[MAX_DIM];
	int idx; //added by ysf
    struct kd_node_t *left, *right;
};
 
inline double dist(struct kd_node_t *a, struct kd_node_t *b, int dim)
{
    double t, d = 0;
    while (dim--) {
        t = a->x[dim] - b->x[dim];
        d += t * t;
    }
    return d;
}
inline void swap(struct kd_node_t *x, struct kd_node_t *y) {
    double tmp[MAX_DIM];
	int tmpIdx; //added by ysf for index support

    memcpy(tmp,  x->x, sizeof(tmp));
	tmpIdx = x->idx; //added by ysf for index support

    memcpy(x->x, y->x, sizeof(tmp));
	x->idx = y->idx; //added by ysf for index support

    memcpy(y->x, tmp,  sizeof(tmp));
	y->idx = tmpIdx; //added by ysf for index support
}
 
 
// see quickselect method (ysf: rosettacode.org/wiki/Quickselect_algorithm) 
struct kd_node_t* find_median(struct kd_node_t *start, struct kd_node_t *end, int idx)
{
    if (end <= start) return NULL;
    if (end == start + 1)
        return start;
 
    struct kd_node_t *p, *store, *md = start + (end - start) / 2;
struct kd_node_t *startCpy = (struct kd_node_t*) calloc(1, sizeof(struct kd_node_t));
startCpy->idx = start->idx;
startCpy->left = start->left;
startCpy->right = start->right;
startCpy->x[0] = start->x[0]; startCpy->x[1] = start->x[1]; startCpy->x[2] = start->x[2];

struct kd_node_t *endCpy = (struct kd_node_t*) calloc(1, sizeof(struct kd_node_t));
endCpy->idx = end->idx;
endCpy->left = end->left;
endCpy->right = end->right;
endCpy->x[0] = end->x[0]; endCpy->x[1] = end->x[1]; endCpy->x[2] = end->x[2];

//memcpy(startCpy,  start, sizeof(struct kd_node_t));memcpy(endCpy,  end, sizeof(struct kd_node_t));

    double pivot;
    while (1) {
        pivot = md->x[idx];
 
        swap(md, end - 1);
        for (store = p = startCpy; p < endCpy; p++) {
            if (p->x[idx] < pivot) {
                if (p != store)
                    swap(p, store);
                store++;
            }
        }
        swap(store, end - 1);
 
        // median has duplicate values
        if (store->x[idx] == md->x[idx])
            return md;
 
        //if (store > md) end = store;
if (store->x[idx] > md->x[idx]) startCpy = store; //corrected by ysf?????????????????????????
        else			    endCpy = store;
    }
}

struct kd_node_t* make_tree(struct kd_node_t *t, int len, int i, int dim)
{
    struct kd_node_t *n;
 
    if (!len) return 0;
 
    if ((n = find_median(t, t + len, i))) {
        i = (i + 1) % dim;
        n->left  = make_tree(t, n - t, i, dim);
        n->right = make_tree(n + 1, t + len - (n + 1), i, dim);
    }

	//cout << "root: " << n->idx << "; " << n->x[0] << " & " << n->x[1] << " & " << n->x[2] << "\n";

    return n;
}
 
// global variable, so sue me
//int visited;
 
void nearest(struct kd_node_t *root, struct kd_node_t *nd, int i, int dim,
        struct kd_node_t **best, double *best_dist)
{
    double d, dx, dx2;
 
//cout << root->x[0] << " rand " << root->x[1] << " rand " << root->x[2] << "\t" << root->idx << endl;
//cout << nd->x[0] << " and " << nd->x[1] << " and " << nd->x[2] << endl << endl;

    if (!root) return;
    d = dist(root, nd, dim);
    dx = root->x[i] - nd->x[i];
    dx2 = dx * dx;
 
    //visited ++;
 
    if (!*best || d < *best_dist) {
        *best_dist = d;
        *best = root;
    }
 
    // if chance of exact match is high
    if (!*best_dist) return;
 
    if (++i >= dim) i = 0;
 
    nearest(dx > 0 ? root->left : root->right, nd, i, dim, best, best_dist);
    if (dx2 >= *best_dist) return;
    nearest(dx > 0 ? root->right : root->left, nd, i, dim, best, best_dist);
}
//////////////// kd-tree stuff ends ////////////////////*/

inline float distanceBetween(float* v1, float* v2)
{
	//Euclidean distance b/w v1 & v2
	return (float) sqrt( (v2[0]-v1[0])*(v2[0]-v1[0]) + (v2[1]-v1[1])*(v2[1]-v1[1]) + (v2[2]-v1[2])*(v2[2]-v1[2]));
}
inline float distanceBetween2(float* v1, float* v2)
{
	//squared Euclidean distance b/w v1 & v2 (no sqrt hence faster; good for comparisons only)
	return (float) (v2[0]-v1[0])*(v2[0]-v1[0]) + (v2[1]-v1[1])*(v2[1]-v1[1]) + (v2[2]-v1[2])*(v2[2]-v1[2]);
}

bool Mesh::loadPnt(char* meshFile)
{
	cout << "Point cloud initializing (to " << meshFile << ")...\n";

	FILE* fPtr;
	if (! (fPtr = fopen(meshFile, "r")))
	{
		cout << "cannot read " << meshFile << endl
			 << "WARNING: all input files must be in a folder named \"input\"; similarly there must exist a folder named \"output\" to write the results to\n";
		//return false;
		exit(0);
	}

	while (! feof( fPtr ) )
	{
		float a, b, c;
		fscanf(fPtr, "%f %f %f\n", &a, &b, &c);
		float* co = new float[3];
		co[0] = a;
		co[1] = b;
		co[2] = c;

//if (strcmp(meshFile, "input\\homer-downscaled-rotated.xyz") == 0) co[0] += 0.2f;

		addVertexND(co); //ND: no duplicate check
	}	

	//data preparation for the algorithm, i.e. edit existing data so that new one is rotated, scaled, and/or cropped
/*FILE* fPtrS = fopen("face-downscaled-rotated.xyz", "w");
float theta = 30.0f * (PI / 180.0f), x, y, z, scaler = 0.7f;
	for (int v = 0; v < (int) verts.size(); v++)
	{
		verts[v]->coords[0] *= scaler; verts[v]->coords[1] *= scaler; verts[v]->coords[2] *= scaler;
	}
	//y-axis rotation by theta degree
	for (int i = 0; i < (int) verts.size(); i++)
	{
		x = verts[i]->coords[2]*sin(theta) + verts[i]->coords[0]*cos(theta);
		z = verts[i]->coords[2]*cos(theta) - verts[i]->coords[0]*sin(theta);
		verts[i]->coords[0] = x;
		verts[i]->coords[2] = z;
	}
	//x-axis rotation by theta degree
	for (int i = 0; i < (int) verts.size(); i++)
	{
		y = verts[i]->coords[1]*cos(theta) - verts[i]->coords[2]*sin(theta);
		z = verts[i]->coords[1]*sin(theta) + verts[i]->coords[2]*cos(theta);
		verts[i]->coords[1] = y;
		verts[i]->coords[2] = z;
	}
	
	for (int v = 0; v < (int) verts.size(); v++)
		fprintf(fPtrS, "%f %f %f\n", verts[v]->coords[0], verts[v]->coords[1], verts[v]->coords[2]);
	fclose(fPtrS);
exit(0);//*/
/*FILE* fPtrS = fopen("bunny-left-downscaled-rotated.xyz", "w");
	float theta = -40.0f * (PI / 180.0f), x, y, z;
	//x-axis rotation by theta degree
	for (int i = 0; i < (int) verts.size(); i++)
	{
		y = verts[i]->coords[1]*cos(theta) - verts[i]->coords[2]*sin(theta);
		z = verts[i]->coords[1]*sin(theta) + verts[i]->coords[2]*cos(theta);
		verts[i]->coords[1] = y;
		verts[i]->coords[2] = z;
	}
	//y-axis rotation by theta degree
	theta = 50.0f * (PI / 180.0f), x, y, z;
	for (int i = 0; i < (int) verts.size(); i++)
	{
		x = verts[i]->coords[2]*sin(theta) + verts[i]->coords[0]*cos(theta);
		z = verts[i]->coords[2]*cos(theta) - verts[i]->coords[0]*sin(theta);
		verts[i]->coords[0] = x;
		verts[i]->coords[2] = z;
	}
	float scaler = 0.7f;
	for (int v = 0; v < (int) verts.size(); v++)
	{
//		cout << verts[v]->coords[0] << "\t";
		if (verts[v]->coords[0] < 0.0f)
			fprintf(fPtrS, "%f %f %f\n", verts[v]->coords[0]*scaler, verts[v]->coords[1]*scaler, verts[v]->coords[2]*scaler);
	}
	fclose(fPtrS);
exit(0);//*/
/*FILE* fPtrS = fopen("bunny-downscaled-rotated.xyz", "w");
float theta = 30.0f * (PI / 180.0f), x, y, z;
	//y-axis rotation by theta degree
	for (int i = 0; i < (int) verts.size(); i++)
	{
		x = verts[i]->coords[2]*sin(theta) + verts[i]->coords[0]*cos(theta);
		z = verts[i]->coords[2]*cos(theta) - verts[i]->coords[0]*sin(theta);
		verts[i]->coords[0] = x;
		verts[i]->coords[2] = z;
	}
	//x-axis rotation by theta degree
	for (int i = 0; i < (int) verts.size(); i++)
	{
		y = verts[i]->coords[1]*cos(theta) - verts[i]->coords[2]*sin(theta);
		z = verts[i]->coords[1]*sin(theta) + verts[i]->coords[2]*cos(theta);
		verts[i]->coords[1] = y;
		verts[i]->coords[2] = z;
	}
	
	float scaler = 0.5f;
	for (int v = 0; v < (int) verts.size(); v++)
	{
//		if (verts[v]->coords[1] < -0.1f)
			fprintf(fPtrS, "%f %f %f\n", verts[v]->coords[0]*scaler, verts[v]->coords[1]*scaler, verts[v]->coords[2]*scaler);
	}
	fclose(fPtrS);
exit(0);//*/
/*FILE* fPtrS = fopen("homer-top-downscaled-rotated.xyz", "w");
float theta = 25.0f * (PI / 180.0f), x, y, z;
	//z-axis rotation by theta degree
	for (int i = 0; i < (int) verts.size(); i++)
	{
		x = verts[i]->coords[0]*cos(theta) - verts[i]->coords[1]*sin(theta);
		y = verts[i]->coords[0]*sin(theta) + verts[i]->coords[1]*cos(theta);
		verts[i]->coords[0] = x;
		verts[i]->coords[1] = y;
	}	
	//y-axis rotation by theta degree
	for (int i = 0; i < (int) verts.size(); i++)
	{
		x = verts[i]->coords[2]*sin(theta) + verts[i]->coords[0]*cos(theta);
		z = verts[i]->coords[2]*cos(theta) - verts[i]->coords[0]*sin(theta);
		verts[i]->coords[0] = x;
		verts[i]->coords[2] = z;
	}	
	float scaler = 0.6f;
	for (int v = 0; v < (int) verts.size(); v++)
	{
//		cout << verts[v]->coords[1] << "\t";
		if (verts[v]->coords[1] > 0.5f)
			fprintf(fPtrS, "%f %f %f\n", verts[v]->coords[0]*scaler, verts[v]->coords[1]*scaler, verts[v]->coords[2]*scaler);
	}
	fclose(fPtrS);
exit(0);//*/
/*	FILE* fPtrS = fopen("surprise-upscaled-rotated.xyz", "w");
float theta = 30.0f * (PI / 180.0f), x, y, z, scaler = 1.2f;
	for (int v = 0; v < (int) verts.size(); v++)
	{
		verts[v]->coords[0] *= scaler; verts[v]->coords[1] *= scaler; verts[v]->coords[2] *= scaler;
	}
	//y-axis rotation by theta degree
	for (int i = 0; i < (int) verts.size(); i++)
	{
		x = verts[i]->coords[2]*sin(theta) + verts[i]->coords[0]*cos(theta);
		z = verts[i]->coords[2]*cos(theta) - verts[i]->coords[0]*sin(theta);
		verts[i]->coords[0] = x;
		verts[i]->coords[2] = z;
	}
	//z-axis rotation by theta degree
	for (int i = 0; i < (int) verts.size(); i++)
	{
		x = verts[i]->coords[0]*cos(theta) - verts[i]->coords[1]*sin(theta);
		y = verts[i]->coords[0]*sin(theta) + verts[i]->coords[1]*cos(theta);
		verts[i]->coords[0] = x;
		verts[i]->coords[1] = y;
	}	
	
	for (int v = 0; v < (int) verts.size(); v++)
		fprintf(fPtrS, "%f %f %f\n", verts[v]->coords[0], verts[v]->coords[1], verts[v]->coords[2]);
	fclose(fPtrS);
exit(0);//*/

	maxEucDist = 0.0f;
	for (int i = 0; i < (int) verts.size(); i++)
		for (int j = 0; j < (int) verts.size(); j++)
			if (distanceBetween(verts[i]->coords, verts[j]->coords) > maxEucDist)
				maxEucDist = distanceBetween(verts[i]->coords, verts[j]->coords);
	cout << "distance b/w farthest 2 points: " << maxEucDist << endl;

	cout << "Point cloud has " << (int) verts.size() << " verts\n\n";
	return true;
}
bool Mesh::loadPlyColor(char* meshFile)
{
	cout << "\nScene initializing (to " << meshFile << ")...\n";

	FILE* fPtr;
	if (! (fPtr = fopen(meshFile, "r")))
	{
		cout << "cannot read " << meshFile << endl;
		//return false;
		exit(0);
	}

	while (! feof( fPtr ) )
	{
		float a, b, c;
		fscanf(fPtr, "%f %f %f ", &a, &b, &c);
		float* co = new float[3];
		co[0] = a;
		co[1] = b;
		co[2] = c;
		addVertexND(co); //ND: no duplicate check

		//color
		fscanf(fPtr, "%f %f %f ", &a, &b, &c);
		float* co2 = new float[3];
		co2[0] = a;
		co2[1] = b;
		co2[2] = c;
		verts[ (int) verts.size()-1 ]->color = co2;
//cout << co2[0] << " " << co2[1] << " " << co2[2] << endl;
		fscanf(fPtr, "%f\n", &a); //transparency info
	}	

	cout << "Scene has " << (int) verts.size() << " verts\n";
	return true;
}

int Mesh::addVertex(float x, float y, float z)
{
	float v[3] = {x, y, z};
	return addVertex(v);
}
int Mesh::addVertex(float* v)
{
	//add v to verts, if not duplicated

	bool duplicateExists = false;
	int i = (int) verts.size();
	
	//duplicate prevention
	float ROUNDING_ERR = 0.01f;
	for (i = (int) verts.size() - 1; i >= 0; i--)
	{
		if (fabs(verts[i]->coords[0] - v[0]) < ROUNDING_ERR && //since i scale stuff initially w/ SCALE_FACTOR = 1000 just in case, ROUNDING_ERR = 0.01f should be good here
			fabs(verts[i]->coords[1] - v[1]) < ROUNDING_ERR &&
			fabs(verts[i]->coords[2] - v[2]) < ROUNDING_ERR)
		{
			duplicateExists = true;
			break;	//more than efficiency: return the correct i by this break
		}
	}
	if (! duplicateExists)
	{
		int idx = (int) verts.size();
		verts.push_back(new Vertex(idx, v));
		return idx; //pointer to this new item (last index)
	}

	//this duplicate vert v is ith element of verts
	return i;
}

void Mesh::addVertexND(float* c)
{
	//fastly add verts w/ coords c to mesh; ND: no duplication check

	int vSize = (int) verts.size(); //size before push_back just-below
	verts.push_back(new Vertex(vSize, c));
}

int Mesh::addTriangle(int v1i, int v2i, int v3i)
{
	//add tri v1i-v2i-v3i to the triInd'th element of tris

	int triInd = (int) tris.size();

	tris.push_back( new Triangle(triInd, v1i, v2i, v3i) );

	//update each vertex with its new tri and vert neighbors
	verts[v1i]->triNeighbors.push_back(triInd);
	//addVertNeighbor returns true if verts[v1i] is not neighbor of [v2i]; so they can form a new edge
	if (verts[v1i]->addVertNeighbor(v2i))	addEdge(v1i, v2i);
	if (verts[v1i]->addVertNeighbor(v3i))	addEdge(v1i, v3i);
	//in other words, a 'false' returned by addVertNeighbor prevents adding the same edge if it already exists

	verts[v2i]->triNeighbors.push_back(triInd);
	verts[v2i]->addVertNeighbor(v1i);	//v1i v2i edge is (probably) added above; do not add v2i v1i edge!!!
	if (verts[v2i]->addVertNeighbor(v3i))	addEdge(v2i, v3i);	//v3i v2i is not added above, so add this if ok

	verts[v3i]->triNeighbors.push_back(triInd);
	verts[v3i]->addVertNeighbor(v1i);	//no addEdge risk, so no if control
	verts[v3i]->addVertNeighbor(v2i);

	return triInd;
}

int Mesh::getEdgeSharedBy(int vi, int vj)
{
	//return idx of edge[vi, vj]

	for (unsigned int vie = 0; vie < verts[vi]->edgeList.size(); vie++)
		for (unsigned int vje = 0; vje < verts[vj]->edgeList.size(); vje++)
			if (verts[vj]->edgeList[vje] == verts[vi]->edgeList[vie])
				return verts[vj]->edgeList[vje];

	//edge not exist
	return -99;
}

void Mesh::addEdge(int v1i, int v2i, bool interiorEdge)
{
	int initial = (int) edges.size();
	Edge* newcomer = new Edge(initial, v1i, v2i, distanceBetween(verts[v1i]->coords, verts[v2i]->coords), interiorEdge);

	//update the list of edges of which verts[v1i] is a member
	//for geodesic computations in dijkstraShortestPaths() i will discard interior edges (v.interiorEdgeList) as geodesic is defined as surface distance and interior edges are just noises distracting the true geodesics; interiorEdges however are necessary for volumetric regulation term in spring system and deformations
	if (interiorEdge)
	{
		verts[v1i]->interiorEdgeList.push_back(newcomer->idx);
		verts[v2i]->interiorEdgeList.push_back(newcomer->idx); //do same thing for [v2i]
	}
	else
	{
		verts[v1i]->edgeList.push_back(newcomer->idx);
		verts[v2i]->edgeList.push_back(newcomer->idx); //do same thing for [v2i]
	}

	edges.push_back(newcomer);

	//information
	if (newcomer->length < minEdgeLen)
		minEdgeLen = newcomer->length;
	if (newcomer->length > maxEdgeLen)
	{
		maxEdgeLen = newcomer->length;
//cout << v1i << " " << v2i << "\t" << newcomer->length << endl;
	}
	edgeLenTotal += newcomer->length;
}

int* Mesh::getTrianglesSharedBy(Edge* bigEdge, int v1i, int v2i)
{
	//returns 2 tris adjacent to bigEdge (where endpnts of bigEdge is v1i and v2i)

	//tri t is shared by bigEdge iff it exists in the triNeigbors of verts[v1i] & [v2i]
	if (v1i == -1) //learn v1i and v2i from bigEdge
	{
		v1i = bigEdge->v1i;
		v2i = bigEdge->v2i;
	}
	int a = 0, tr1, tr2;
	int* shTris = new int[2];	//portable version (memo-friendly as well 'cos i delete shrdTris in split/flip())
	//seeing this took my 6 hours!!! prevent removed triangles from being selected as shared!
	for (unsigned int t1 = 0; t1 < verts[v1i]->triNeighbors.size(); t1++)
	{
		tr1 = verts[v1i]->triNeighbors[t1];
		for (unsigned int t2 = 0; t2 < verts[v2i]->triNeighbors.size(); t2++)
		{
			tr2 = verts[v2i]->triNeighbors[t2];
			if  (tris[tr2] != 0 && (tr1 == tr2))
				shTris[a++] = tr1; //or tr2
		}
	}
	//if called from split/flip, a is certainly incremented by 1; but it remains at 1 (no more ++) 
	//if bigEdge is a border edge (not in my case 'cos my mesh is closed); take precautions anyway;
	if (a == 1) shTris[1] = -1;	//number -1 must not change 'cos used by somewhere else
if (shTris[1] == -1) cout << v1i << "," << v2i << " is a border edge found in my closed-mesh :(\n\n"; //exit(0);}

//if called from contract, a may remain 0, which tells me to remove that edgesAdded[cea] neighbor to 2 removed tris
if (a == 0)	shTris[0] = -1;	//since that part of contract() is inactive, don't care here

//assert(shTris[0] != shTris[1]);
	return shTris;
}

void Mesh::computeSamples(int n)
{
	//computation of n sample vertices

//	cout << "\nSampling in action..\n";

	if (! samples.empty())
		return; //already computed so do nothing

#ifdef VERBOSE
	cout << "Evenly-spaced sampling [" << N << "]......\n";
#endif
	int extremeVert = getAnExtremeVert();
	samples.push_back(extremeVert);
//	cout << samples[0] << " ";
	verts[extremeVert]->sample = true;
	//fill the remaining N-1 items via fps for uniform distribution that lets nice coverage on models
	while ((int) samples.size() < n)
	{
		//in fps, the next sample candidate x_i \in all vertices finds its closest existing sample x_clo and remembers d_i = d(x_i, x_clo); if d_i is the max among all other candidates closest remembered dists, then x_i is selected as the next sample;
		//here my candidates are restricted to nothing, i.e. i use all verts as candidates; so, find the closest existing sample e2 \in samples to s \in verts and add s to samples as nextSample if that closest dist is very big, i.e. the biggest among all closest dists for different s's
		float maxDist = -INF;
		int nextSample = -1;				
		for (int s = 0; s < (int) verts.size(); s++) //fps selects from amongst all vertices
		{
			int e2 = -1;
			if (verts[s]->sample)
				continue; //no chance to select s as a sample 'cos it's already added to samples[]

			float minDist = distanceBetween(verts[ samples[0] ]->coords, verts[ s ]->coords); //=INF is tricky 'cos objects may be scaled to those high coordinates			
			for (int e = 0; e < (int) samples.size(); e++) //find the closest existing base e \in samples to s \in verts
			{
				float dist = distanceBetween(verts[ samples[e] ]->coords, verts[ s ]->coords);
				if (dist <= minDist)
				{
					minDist = dist;
					e2 = samples[e];
				}
			}
			float dist = distanceBetween(verts[ e2 ]->coords, verts[ s ]->coords);
			if (dist > maxDist)
			{
				maxDist = dist;
				nextSample = s;
			}
		} //end of for s
		if (nextSample == -1) {cout << "can't happen in FPS\n"; exit(0);}
		samples.push_back(nextSample);
		verts[nextSample]->sample = true;

/*		int i = (int) samples.size();
		if (i < 5 || i > n-4) //print the first and last 4 sample ids
			cout << samples[i-1] << " ";
		else if (i == 5)
			cout << " .. ";*/
	} //end of while n
//for (int v = 0; v < (int) verts.size(); v++) cout << verts[ 6 ]->dSpanningUnn[ v ] << "\t"; //if verts6 is disconnected this prints INF for all except v=6 (prints 0 to itself); easier: check valence edgeList.size

/*	cout << "\nk-nearest neighbs to each sample..\n";
	int k = 6; //k nearest-neighbors of each sample
	for (int b = 0; b < (int) samples.size(); b++)
		computeNeighbors(samples[b], k);
	cout << endl;*/
}
int Mesh::getAnExtremeVert()
{
	//returns idx of an extreme vertex, e.g. on hand or toe

	//vertex that is farthest away from arbitraryVert is definitely an extreme, where arbitraryVert can be anywhere on mesh (center, tips, head, ..)
	int arbitraryVert = 0, result = -1;
	float maxDist = -INF;
	for (int s = 0; s < (int) verts.size(); s++) //fps selects from amongst all vertices
		if (distanceBetween2(verts[s]->coords, verts[arbitraryVert]->coords) > maxDist)
			{
				maxDist = distanceBetween2(verts[s]->coords, verts[arbitraryVert]->coords);
				result = s;
			}
	return result;
}
void Mesh::computeNeighbors(int v, int k)
{
	//computes k nearest-neighbors of vertex v

	for (int j = 0; j < (int) verts.size(); j++)
		verts[j]->processed = false; //true means it's already added to v.kneighbs so not add it again and prevent duplicates
	float center[3] = {0.0f, 0.0f, 0.0f}; //centroid of the k nearest-neighbors
	for (int i = 0; i < k; i++)
	{
		float minDist = INF;
		int neighb;
		for (int j = 0; j < (int) verts.size(); j++)
			if (j != v)
			{
				float dist = distanceBetween(verts[v]->coords, verts[j]->coords);
				if (dist < minDist && ! verts[j]->processed)
				{
					neighb = j;
					minDist = dist;
				}
			}
		verts[v]->kneighbs.push_back(neighb);
		verts[neighb]->processed = true;
		for (int c = 0; c < 3; c++)
			center[c] += verts[neighb]->coords[c];
	}
	for (int c = 0; c < 3; c++)
		center[c] /= k;
	verts[v]->desc = distanceBetween(center, verts[v]->coords);
//	cout << verts[v]->desc << "\t";
}

float Mesh::ICP(Mesh* mesh2, bool adaptiveScaling, int nMaxIters, bool oneToOne, float minDisplacement)
{
	//transform this mesh towards the fixed mesh2 using ICP; closed-form rotation matrix is from eq. 21 of the original paper: A Method for Registration of 3-D Shapes

#ifdef KDTREE_FOR_CLOSEST_PNTS
	cout << (adaptiveScaling ? "Scale-Adaptive " : "") << "ICP in action..\n";
#else
	cout << (adaptiveScaling ? "Scale-Adaptive " : "") << "ICP in action (kd-tree not in use; affects running time drastically for large inputs)..\n";
#endif

	bool matured = false, prescale = false; //true to prescale input pairs, i.e., ratio b/w [distance b/w farthest 2 points on fixed mesh2] and [distance b/w farthest 2 points on transforming mesh1]
	if (prescale)		
		for (int v = 0; v < (int) verts.size(); v++)
			for (int c = 0; c < 3; c++)
				verts[v]->coords[c] *= (mesh2->maxEucDist / maxEucDist); //scaled by the euclidean ratio

	int nSamples = 10;//50;//10;//50;
	computeSamples(nSamples);
	mesh2->computeSamples(nSamples);
	cout << "\n\n";

	bool samplesInUse = false, //true to use samples (vertex subset) while computing the ICP transformation; false to use all verts
		 perfCorrMode = false; //true to use ground-truth correspondences which makes ICP complete perfectly in 1 shot; the success here verifies that if i have nice descriptors (that enable automatic correspondences) my algo would be successful
	vector< int > sampCopy, samp2Copy;
	if (! samplesInUse)
	{
		//put all verts in samples[] 'cos code below uses samples[] everywhere; protect original samples[] in copy vectors
		sampCopy = samples;
		samp2Copy = mesh2->samples;
		samples.clear();
		for (int i = 0; i < (int) verts.size(); i++)
			samples.push_back(i);
		mesh2->samples.clear();
		for (int i = 0; i < (int) mesh2->verts.size(); i++)
			mesh2->samples.push_back(i);
	}

	//center of masses of the k-d point sets
	int k = 3, nP1 = (int) samples.size(), nP2 = (int) mesh2->samples.size(); //size of point set 1 (transforming set) and point set 2 (fixed set); currently this function assumes samples[] in use; easy to modify for other usages, e.g. verts[]
//assert(nVoxels >= nVerts); //small-size mesh is moving towards fixed voxels by establishing nVerts-size closest pnt correspondences w/ which the crucial cross-covariance mtrx is filled (some voxels may remain unmatched and corresp may be many to one)
	float* m1 = new float[3], * m2 = new float[3];
	float sum[3] = {0.0f, 0.0f, 0.0f};
	for (int i = 0; i < nP1; i++)
		for (int c = 0; c < 3; c++)
			sum[c] += verts[ samples[i] ]->coords[c];
	for (int c = 0; c < 3; c++)
		m1[c] = sum[c] / (float) nP1;
	sum[0] = sum[1] = sum[2] = 0.0f;
	for (int i = 0; i < nP2; i++)
		for (int c = 0; c < 3; c++)
			sum[c] += mesh2->verts[ mesh2->samples[i] ]->coords[c];
	for (int c = 0; c < 3; c++)
		m2[c] = sum[c] / (float) nP2;

	MatrixXf ms1(k, nP1), ms2(k, nP1); //mean-shifted kxnP1 matrix for the mesh1.samples and matched samples in mesh2; X is for dynamic size f is for float
	Matrix3f cov12; //kxk cross-covariance mtrx of 2 sets, mesh & voxels where k = 3
	Matrix4f Q; //complicated mtrx created using cov12

	float** R1 = new float*[3]; //desired 3x3 rotation mtrx of current iteration
	for (int i = 0; i < 3; i++)
		R1[i] = new float[3];
	float* t1 = new float[3]; //desired 1x3 translation

#ifdef KDTREE_FOR_CLOSEST_PNTS
	//k-d tree holding the fixed mesh2 coordinates and their corresponding idxs to speed up the closest pnt search below
	struct kd_node_t* kdRoot;
	double bestDist;
	struct kd_node_t* pnts2 = (struct kd_node_t*) calloc(nP2, sizeof(struct kd_node_t)); //calloc() zero-initializes the buffer, while malloc() leaves the memory uninitialized; hence calloc slower
	for (int i = 0; i < nP2; i++)
	{				
		pnts2[i].idx = mesh2->samples[i];
		pnts2[i].x[0] = mesh2->verts[ mesh2->samples[i] ]->coords[0];
		pnts2[i].x[1] = mesh2->verts[ mesh2->samples[i] ]->coords[1];
		pnts2[i].x[2] = mesh2->verts[ mesh2->samples[i] ]->coords[2];
	}
	kdRoot = make_tree(pnts2, nP2, 0, 3);
#endif

	//parameters of the linear system to be solved in adaptiveScaling mode
	float A, B, * C = new float[3], * D = new float[3];	
	//iteration parameters
	int nIters = 0;
	float mse = INF, prevMse = 0.0f, //mean-square error objective function to be minimized
		  alignErr = 100.0f, closeness = 0.000000000001f; //0.0000001f;//for face.xyz  //0.00001f;//for completehomer.xyz
	while (++nIters <= nMaxIters)
	{
//break;//see the initial alignment (no ICP)
		if (//nIters > 70 && //activate closeness test after a good deal of iters; a heuristic no in use
			fabs(mse - prevMse) <= closeness)
			break;

		//new center of mass of the transforming mesh
		sum[0] = sum[1] = sum[2] = 0.0f;
		for (int v = 0; v < nP1; v++)
			for (int c = 0; c < 3; c++)
				sum[c] += verts[ samples[v] ]->coords[c];
		for (int c = 0; c < 3; c++)
			m1[c] = sum[c] / (float) nP1;

		//before filling ms1, i need closest-pnt correspondence b/w this mesh & mesh2
		bool oneToOneMatches = oneToOne;//true; //true means 1-to-1 matching will be used b/w this mesh points and mesh2 points, i.e., no mesh2 point appears more than once in the closest-pnt matching (good for scaleAdaptive since it prevents selection of the same points over and over again when the scale difference is high)
//oneToOneMatches = false; //make it false for face.xyz stuff except face-bottom-upscaled-rotated2 and 3 (0.5f for 3)
		int nMatched2 = 0; //# of matched mesh2 vertices of the previous iteration				
		if (fabs(mse - prevMse) < minDisplacement/*0.001f or 0.00001f*/ || matured //relax one-to-one condition (= convert true to false) since the movement was so small compared to the previous iteration
			|| nP1 > nP2) //this should not occur 'cos fixed mesh2 should be the bigger (more complete) one anyway; when aligning camel (1) to fixed lion (2), however, nP1 > nP2 so disable oneToOneMatches just in case
		//if (nIters > 5) //relaxation kicks in too late for bunny; fix it via nIters condition; handled it by using 0.001f above
		{
			if (! matured && oneToOneMatches)
				cout << "disabling one-to-one pairing of points (" << fabs(mse - prevMse) << ", " << nIters << ")\n";
			matured = true;
			oneToOneMatches = false;
		}		
		if (oneToOneMatches)
		{
			for (int i = 0; i < nP2; i++)
			{
				if (mesh2->verts[i]->closestVertIdx != -1)
					nMatched2++;
				//get ready for the upcoming iteration; to prevent selection of a mesh2 vertex more than once, i use closestVertIdx==-1 flag
				mesh2->verts[i]->closestVertIdx = -1;
			}
//			if (nIters > 1)
//				cout << nMatched2 << " / " << nP2 << " mesh2 points were the closest points to " << nP1 << " mesh1 points in the prev iteration (" << nIters-1 << ")\n";
		}

		float dist; //closest w.r.t. Euclidean distance
		vector< int > matchedP2s; //idxs of mesh2 points that are matched to mesh1 points
#ifdef KDTREE_FOR_CLOSEST_PNTS
		//oneToOneMatches=true stuff is not implemented for the kd-tree mode yet; it's straightforward though
		//using a k-d tree for nP1 x log(nP2) performance instead of nP1 x nP2 of the simple exhaustive search below
		for (int bv1 = 0; bv1 < nP1; bv1++) //for each mesh verts
		{
			struct kd_node_t testNode, * found;
			testNode.x[0] = verts[ samples[bv1] ]->coords[0];
			testNode.x[1] = verts[ samples[bv1] ]->coords[1];
			testNode.x[2] = verts[ samples[bv1] ]->coords[2];
			nearest(kdRoot, &testNode, 0, 3, &found, &bestDist); //print sqrt(bestDist) as nearest() works w/ squared distances for efficiency
			mesh2->verts[found->idx]->closestVertIdx = samples[bv1];
			matchedP2s.push_back(found->idx);
//if (nIters % 10 == 1) cout << samples[bv1] << " -- " << found->idx << endl;
		}
#else
		//exhaustive search for closest matches in quadratic time
		for (int bv1 = 0; bv1 < nP1; bv1++) //for each mesh verts
		{
			float minDist = INF;
			int mv = -1;
			for (int bv2 = 0; bv2 < nP2; bv2++) //find its closest voxel match
			{				
				if (! oneToOneMatches)												//previously selected point can still be selected
				{
					dist = distanceBetween2(mesh2->verts[ mesh2->samples[bv2] ]->coords, verts[ samples[bv1] ]->coords); //omit sqrt() to save time
					if (dist < minDist)
					{
						minDist = dist;
						mv = mesh2->samples[bv2];
					}
				}
				else if (mesh2->verts[ mesh2->samples[bv2] ]->closestVertIdx == -1)	//previously selected point cannot be selected in this oneToOneMatches mode
				{
					dist = distanceBetween2(mesh2->verts[ mesh2->samples[bv2] ]->coords, verts[ samples[bv1] ]->coords); //omit sqrt() to save time
					if (dist < minDist)
					{
						minDist = dist;
						mv = mesh2->samples[bv2];
					}
				}
			}
			if (mv == -1)
				cout << "WARNING: this may happen in oneToOneMatches mode if a valid mesh2 point candidate cannot be found; easy fix: oneToOneMatches=false\n";
			matchedP2s.push_back(mv);
			mesh2->verts[mv]->closestVertIdx = samples[bv1];
		}
#endif



if (perfCorrMode){
matchedP2s.clear();//set i-i correspondences w/ dealing w/ closest-point metric (or other metric) for correspondence; note that i-i corresps may suck for partial vs. complete cases since partial indexes are probably shifted
for (int bv1 = 0; bv1 < nP1; bv1++) {
int p2idx = samples[bv1]; //assume i-i ground-truth correspondence
mesh2->verts[p2idx]->closestVertIdx = samples[bv1];matchedP2s.push_back(p2idx); }}//*/




		//now that closest pnt correspondence done, i.e. closestVertIdx's are set, i can fill ms1
		//fill mean-shifted kxnP1 ms1 matrix for the 1st set (mesh1)
		for (int i = 0; i < k; i++) //for all k rows
			for (int j = 0; j < nP1; j++) //fill columns
				ms1(i, j) = verts[ mesh2->verts[ matchedP2s[j] ]->closestVertIdx ]->coords[i] - m1[i];
		//fill mean-shifted 3xnVerts matrix for the 2nd set (matched voxels, hence of size nVerts for sure)
		//new center of mass of the newly matched voxels
		sum[0] = sum[1] = sum[2] = 0.0f;
		for (int v = 0; v < nP1; v++)
			for (int c = 0; c < 3; c++)
				sum[c] += mesh2->verts[ matchedP2s[v] ]->coords[c];
		for (int c = 0; c < 3; c++)
			m2[c] = sum[c] / (float) nP1;
		//fill mean-shifted kxnP1 ms2 matrix for the mesh2; X is for dynamic size f is for float
		for (int i = 0; i < k; i++) //for all k rows
			for (int j = 0; j < nP1; j++) //fill n1 columns
				ms2(i, j) = mesh2->verts[ matchedP2s[j] ]->coords[i] - m2[i];
		MatrixXf ms2t = ms2.transpose(); //transpose of ms

		//kxk cross-covariance mtrx b/w mesh1 and mesh2
		cov12 = ms1 * ms2t; //k x nP1 * nP1 x k
		for (int i = 0; i < 3; i++)
			for (int j = 0; j < 3; j++)
				cov12(i, j) /= nP1;

		//Q = 4x4 complicated mtrx, see the paper
		Q(0, 0) = cov12(0, 0) + cov12(1, 1) + cov12(2, 2);
		Q(1, 0) = Q(0, 1) = cov12(1, 2) - cov12(2, 1); //(paper notation: S23 - S32, say S to cov12, and idxs of paper, i.e. start from 1)
		Q(2, 0) = Q(0, 2) = cov12(2, 0) - cov12(0, 2); //S31 - S13
		Q(3, 0) = Q(0, 3) = cov12(0, 1) - cov12(1, 0); //S12 - S21
		Q(1, 1) = 2*cov12(0, 0) - Q(0, 0);		Q(1, 2) = cov12(0, 1) + cov12(1, 0);	Q(1, 3) = cov12(0, 2) + cov12(2, 0);
		Q(2, 1) = cov12(1, 0) + cov12(0, 1);	Q(2, 2) = 2*cov12(1, 1) - Q(0, 0);		Q(2, 3) = cov12(1, 2) + cov12(2, 1);
		Q(3, 1) = cov12(2, 0) + cov12(0, 2);	Q(3, 2) = cov12(2, 1) + cov12(1, 2);	Q(3, 3) = 2*cov12(2, 2) - Q(0, 0);
		//desired rotation is decided by 1x4 quaternion vector, which is the (largest eigval's) eigvec of Q
		SelfAdjointEigenSolver<Matrix4f> eigensolver(Q); //solve eigenvalue/vector for symmetric n by n matrices, a.k.a. selfadjoint matrices
		if (eigensolver.info() != Success) abort();
		Vector4f eig_vals = eigensolver.eigenvalues(); //given in ascending order
		Matrix4f eig_vecs = eigensolver.eigenvectors(); //last column of eig_vecs corresponds to the largest eigenvalue, hence the one i want
		
		//1x4 quaternion = [q0, q1, q2, q3]
		float q0 = eig_vecs(0, 3), q1 = eig_vecs(1, 3), q2 = eig_vecs(2, 3), q3 = eig_vecs(3, 3);
		//if (q0 < 0) { q0 = -q0;	q1 = -q1;	q2 = -q2;	q3 = -q3; } //needed??????????

		//fill desired 3x3 rotation mtrx (i'm used to 4x4 mtrxs w/ coords but this 3x3 works 'cos of quaternions, i guess)
		R1[0][0] = q0*q0 + q1*q1 - q2*q2 - q3*q3;	R1[0][1] = 2*(q1*q2 - q0*q3);				R1[0][2] = 2*(q1*q3 + q0*q2);
		R1[1][0] = 2*(q1*q2 + q0*q3);				R1[1][1] = q0*q0 + q2*q2 - q1*q1 - q3*q3;	R1[1][2] = 2*(q2*q3 - q0*q1);
		R1[2][0] = 2*(q1*q3 - q0*q2);				R1[2][1] = 2*(q2*q3 + q0*q1);				R1[2][2] = q0*q0 + q3*q3 - q1*q1 - q2*q2;
		if (! adaptiveScaling) //classical ICP that doesn't bother w/ uniform scaling
		{
			//fill desired 1x3 translation: a vector from rotated/transformed mean1 to the fixed mean2 (m2); rotation not applied to the actual coords yet so this is like an uncommitted transation
			t1[0] = m2[0] - (R1[0][0]*m1[0] + R1[0][1]*m1[1] + R1[0][2]*m1[2]);
			t1[1] = m2[1] - (R1[1][0]*m1[0] + R1[1][1]*m1[1] + R1[1][2]*m1[2]);
			t1[2] = m2[2] - (R1[2][0]*m1[0] + R1[2][1]*m1[1] + R1[2][2]*m1[2]);

			//apply transformation of this iteration to all verts of the transforming mesh; even if i use samples[] only in the computation of ICP transformation (samplesInUse=true), all verts are transformed here
			for (int v = 0; v < (int) verts.size(); v++)
			{
				//first rotation then translation (first translation then rotation also works)
				//rotation
				float x = verts[v]->coords[0],
					  y = verts[v]->coords[1],
					  z = verts[v]->coords[2];
				verts[v]->coords[0] = R1[0][0]*x + R1[0][1]*y + R1[0][2]*z;
				verts[v]->coords[1] = R1[1][0]*x + R1[1][1]*y + R1[1][2]*z;
				verts[v]->coords[2] = R1[2][0]*x + R1[2][1]*y + R1[2][2]*z;
	
				//translation
				verts[v]->coords[0] += t1[0];
				verts[v]->coords[1] += t1[1];
				verts[v]->coords[2] += t1[2];
			}			
		}
		else //our ICP that solves for translation and uniform scaling simulataneously to improve the initial scale guess as well
		{
			//the math of this part is explained in my paper titled Skuller; check it out
			A = B = 0.0f;
			for (int i = 0; i < 3; i++)
				C[i] = D[i] = 0.0f;
			//apply just ICP rotation of this iteration to all verts of the transforming mesh; even if i use samples[] only in the computation of ICP transformation (samplesInUse=true), all verts are transformed here
			for (int v = 0; v < (int) verts.size(); v++)
			{
				float x = verts[v]->coords[0],
					  y = verts[v]->coords[1],
					  z = verts[v]->coords[2];
				//rotation
				verts[v]->coords[0] = R1[0][0]*x + R1[0][1]*y + R1[0][2]*z;
				verts[v]->coords[1] = R1[1][0]*x + R1[1][1]*y + R1[1][2]*z;
				verts[v]->coords[2] = R1[2][0]*x + R1[2][1]*y + R1[2][2]*z;
			}
			for (int v = 0; v < nP1; v++)
			{
				//D = [Dx Dy Dz] is computed Dx is the sum of x-coords of all matched mesh2 points, and so on (since matched mesh2 points change each iteration D is not fixed); similarly C = [Cx Cy Cz] for transformed, i.e. ICP-rotated, mesh points
				for (int i = 0; i < 3; i++)
				{
					D[i] += mesh2->verts[ matchedP2s[v] ]->coords[i];
					C[i] += verts[ samples[v] ]->coords[i];
				}
				A += verts[ samples[v] ]->coords[0]*verts[ samples[v] ]->coords[0] + verts[ samples[v] ]->coords[1]*verts[ samples[v] ]->coords[1] + verts[ samples[v] ]->coords[2]*verts[ samples[v] ]->coords[2];
				B += verts[ samples[v] ]->coords[0]*mesh2->verts[ matchedP2s[v] ]->coords[0] + verts[ samples[v] ]->coords[1]*mesh2->verts[ matchedP2s[v] ]->coords[1] + verts[ samples[v] ]->coords[2]*mesh2->verts[ matchedP2s[v] ]->coords[2];
			}
			//solve for Px = r linear system to decide x = [s t1.x t1.y t1.z] where s is the uniform scale factor, t1[] is the rotation
			Matrix4f P;
			P << A,C[0],C[1],C[2],	C[0],(float)nP1,0.0f,0.0f,	C[1],0.0f,(float)nP1,0.0f,	C[2],0.0f,0.0f,(float)nP1;
//cout << "Here is the matrix P:\n" << P << endl;
			Vector4f r;
			r << B,D[0],D[1],D[2];
//cout << "Here is the right hand side r:\n" << r << endl;
			Vector4f x = P.jacobiSvd(ComputeFullU | ComputeFullV).solve(r); //s = x(0) is the uniform scale factor, and the rest is the translation t1
//cout << "The least-squares solution is:\n" << x << "\nsame as r?\n" << P * x << endl;
			//apply translation and scaling to all vertices
			for (int v = 0; v < (int) verts.size(); v++)
			{
				//scaling
				verts[v]->coords[0] *= x(0);
				verts[v]->coords[1] *= x(0);
				verts[v]->coords[2] *= x(0);

				//translation
				verts[v]->coords[0] += x(1);
				verts[v]->coords[1] += x(2);
				verts[v]->coords[2] += x(3);
			}
//cout << x(0) << "\t\t" << x(1) << " " << x(2) << " " << x(3) << "\n";//cout << x(0) << " ";
		}

		prevMse = mse; //mse of previous iteration as a termination condition
		//compute new mse value as an iteration condition
		mse = 0.0f;
		for (int bv2 = 0; bv2 < nP1; bv2++)
		{
			//squared distance b/w (target) matched voxel and its closest match in mesh whose coords just updated above
			dist = pow(mesh2->verts[ matchedP2s[bv2] ]->coords[0] - verts[ mesh2->verts[ matchedP2s[bv2] ]->closestVertIdx ]->coords[0], 2.0f) +
				   pow(mesh2->verts[ matchedP2s[bv2] ]->coords[1] - verts[ mesh2->verts[ matchedP2s[bv2] ]->closestVertIdx ]->coords[1], 2.0f) +
				   pow(mesh2->verts[ matchedP2s[bv2] ]->coords[2] - verts[ mesh2->verts[ matchedP2s[bv2] ]->closestVertIdx ]->coords[2], 2.0f);
			mse += dist; //no sqrt() above for efficiency, hence dist = squared dist indeed
		}
		mse /= nP1;
		if (nIters % 10 == 1)
			cout << "mse of ICP iter" << nIters-1 << ": " << mse << "\tmse diff: " << fabs(mse - prevMse) << endl;
	} //end of while nIters/mse

	//recapture memo
	for (int i = 0; i < 3; i++) delete [] R1[i]; delete [] R1;
	delete [] t1;
	delete [] C;
	delete [] D;

	cout << nIters-1 << "'th ICP iteration w/ final mse: " << mse << "\nICP done!\n";
	if (! samplesInUse)
	{
		//recover the original sample in case i need them later
		samples = sampCopy;
		mesh2->samples = samp2Copy;
	}
	return mse;
}
float Mesh::ICPRansac(Mesh* mesh2, bool adaptiveScaling)
{
	//same as ICP() except this one randomly^ selects 3 samples from mesh1 and tries all triplets of samples from mesh2 to form a base correspondence; then computes the transformation that aligns these 3-samples sets and applies it to all points and measures the MSE; (repeat nRepeats times and) return the best result in MSE sense
	//^ not random: i'll select the 3^^ extremities (first 3 samples from FPS inited at an extreme vertex) from mesh1; mesh1 is the transforming partial shape which is definetely included in the complete and fixed mesh2; so this trick works; 3 extremities are wide-spread which is good as shown in 4PCS paper's figure 2

	//WARNING: adaptiveScaling OK when mesh1 is complete (not partial); when partial it fails sometimes 'cos triplet may not form a good matching; TODO: check the baseCorrespPermuted when mesh1 is partial

	cout << "ICP RANSAC in action (adaptiveScaling " << (adaptiveScaling ? "ON)\n" : "OFF)\n");

	//samples representing dense point sets
	int nSamples1 = 10, nSamples2 = 100, //only 3 samples from mesh1 and all dense samples from mesh2 will be used; so keep nSamples1 low (=3 is enough but doing 10 for fun) and nSamples2 high
		nVerts1 = (int) verts.size(), nVerts2 = (int) mesh2->verts.size();
//nSamples1 = nSamples2 = 50;
//nSamples2 = 200;
	computeSamples(nSamples1);
	mesh2->computeSamples(nSamples2);	
	int mseUsing = ALL_VERTS,//ALL_VERTS,//ALL_SAMPLES,//CURRENT_TRIPLET, //compute MSE using either all vertices or all samples or current triplet; samples are not necessarily jointly consistent so do the mse test using all vertices (slow but more accurate); current_triplet is super fast and reasonable?
		nRepeats = 1; //^^repeat ICPRansac() for nRepeats different choices of mesh1 triplets; set it to 1 to use 3 extremities as the only 1 mesh1 triplet
	cout << "\n# samples1 & # samples 2 & mse: " << nSamples1 << " & " << nSamples2 << " & " << mseUsing << "\n\n";
//return 0;//see the samples only

//	if (nRepeats > 1)
		//without srand the program would have generated the same number each time we ran it because the generator would have been seeded with the same default value each time; now it'll be seeded w/ sys time and generate different numbers
//		srand( (unsigned) time(NULL) );

	//size of k-dimensional point set 1 (transforming set) and k-dimensional point set 2 (fixed set)
	int k = 3, nP1 = 3, nP2 = 3;
	/////////// memory allocations to be done only once ///////////
	float* m1 = new float[3], * m2 = new float[3], * sum = new float[3], * C = new float[3], * D = new float[3], A, B;
	float** R1 = new float*[3]; //desired 3x3 rotation mtrx of current iteration
	for (int i = 0; i < 3; i++)
		R1[i] = new float[3];
	float* t1 = new float[3]; //desired 1x3 translation
	MatrixXf ms1(k, nP1), ms2(k, nP1); //mean-shifted kxnP1 matrix for the mesh1.samples and matched samples in mesh2; X is for dynamic size f is for float
	Matrix3f cov12; //kxk cross-covariance mtrx of 2 sets, mesh & voxels where k = 3
	Matrix4f Q; //complicated mtrx created using cov12		
	for (int v = 0; v < nVerts1; v++)
	{
		verts[v]->coordsOriginal = new float[3];
		verts[v]->coordsBest = new float[3];
		for (int c1 = 0; c1 < 3; c1++)
			verts[v]->coordsBest[c1] = verts[v]->coords[c1];
	}
	int perms3[6][3] = {{5, 3, 1}, {5, 1, 3}, {3, 1, 5}, {3, 5, 1}, {1, 3, 5}, {1, 5, 3}}; //3!=6 permutations of indices 1, 3, 5 (mesh2 stuff in indices 1,3,5 in baseCorrespondence)
#ifdef KDTREE_FOR_CLOSEST_PNTS
	//k-d tree holding the fixed mesh2 coordinates and their corresponding idxs to speed up the closest pnt search below
	struct kd_node_t* kdRoot;
	double bestDist;
	if (mseUsing == ALL_VERTS)
	{
		struct kd_node_t* pnts2 = (struct kd_node_t*) calloc(nVerts2, sizeof(struct kd_node_t)); //calloc() zero-initializes the buffer, while malloc() leaves the memory uninitialized; hence calloc slower
		for (int i = 0; i < nVerts2; i++)
		{				
			pnts2[i].idx = i;
			pnts2[i].x[0] = mesh2->verts[ i ]->coords[0];
			pnts2[i].x[1] = mesh2->verts[ i ]->coords[1];
			pnts2[i].x[2] = mesh2->verts[ i ]->coords[2];
if (i==0) cout << pnts2[0].x[0] << " mt " << pnts2[0].x[1] << " mt " << pnts2[0].x[2] << " mtiiiiiiiiiiiiii " << endl;
		}
		kdRoot = make_tree(pnts2, nVerts2, 0, 3);
cout << pnts2[0].x[0] << " mt " << pnts2[0].x[1] << " mt " << pnts2[0].x[2] << " mt " << endl;
	}
	else if (mseUsing == ALL_SAMPLES)
	{
		struct kd_node_t* pnts2 = (struct kd_node_t*) calloc(nSamples2, sizeof(struct kd_node_t)); //calloc() zero-initializes the buffer, while malloc() leaves the memory uninitialized; hence calloc slower
		for (int i = 0; i < nSamples2; i++)
		{				
			pnts2[i].idx = mesh2->samples[i];
			pnts2[i].x[0] = mesh2->verts[ mesh2->samples[i] ]->coords[0];
			pnts2[i].x[1] = mesh2->verts[ mesh2->samples[i] ]->coords[1];
			pnts2[i].x[2] = mesh2->verts[ mesh2->samples[i] ]->coords[2];
		}
		kdRoot = make_tree(pnts2, nSamples2, 0, 3);
	}
#endif
	/////////// memory allocations to be done only once ends ///////////
	float minMSE = INF;
	for (int rep = 0; rep < nRepeats; rep++)
	{
		vector< int > baseCorrespondence, baseCorrespPermuted;
		for (int i = 0; i < 3; i++)
		{
			if (nRepeats == 1) //go with the first 3 extremities in this case
				baseCorrespondence.push_back(samples[i]);
			else
			{
				int r1 = rand() % nSamples1; //random integer in [0, nSamples1) interval
				if (i == 0)
					baseCorrespondence.push_back((rep > 0 ? samples[r1] : samples[i])); //first triplet (rep=0) is the first 3 extremities
				else
				{
					//ensure all 3 random samples are distinct
					if (i == 1 && samples[r1] != baseCorrespondence[0])
						baseCorrespondence.push_back((rep > 0 ? samples[r1] : samples[i])); //first triplet (rep=0) is the first 3 extremities
					else if (i == 1 && samples[r1] == baseCorrespondence[0])
					{
						i--;
						continue; //try again for i=1
					}
					if (i == 2 && samples[r1] != baseCorrespondence[0] && samples[r1] != baseCorrespondence[2])
						baseCorrespondence.push_back((rep > 0 ? samples[r1] : samples[i])); //first triplet (rep=0) is the first 3 extremities
					else if (i == 2 && (samples[r1] == baseCorrespondence[0] || samples[r1] == baseCorrespondence[2]))
					{
						i--;
						continue; //try again for i=2
					}
				}
			}
			baseCorrespondence.push_back(-1); //to be decided based on all triplets of samples from mesh2
		}
//if (nRepeats>1) {for (int i = 0; i < 3; i++) cout << baseCorrespondence[2*i] << " " << baseCorrespondence[2*i+1] << endl;exit(0);}//sanity check
	
		//initial center of mass of the transforming mesh1
		sum[0] = sum[1] = sum[2] = 0.0f;
		for (int i = 0; i < nP1; i++)
			for (int c = 0; c < 3; c++)
				sum[c] += verts[ baseCorrespondence[2*i] ]->coords[c]; //even indices (2i) for mesh1
		for (int c = 0; c < 3; c++)
			m1[c] = sum[c] / (float) nP1;
		
		int nWellMatcheds = 0, nTriplets = 0;
		//triplet from mesh1 (even indices of baseCorrespondence) will be tested with all the C(nSamples2,3) triplets from mesh2; here are all these triplets		
		for (int a = 0; a < nSamples2; a++)
			for (int b = a+1; b < nSamples2; b++)
				for (int c = b+1; c < nSamples2; c++)
				{
					//need 3! permutations of baseCorrespondence to fully evaluate this triplet pair (first 3 samples in mesh1 vs. samples[a]-[b]-[c] from mesh2)
					for (int perm = 0; perm < 6; perm++)
					{
						int ii = 0;
						baseCorrespondence[2*ii++ + 1] = mesh2->samples[a]; //odd indices (2i+1) for mesh2
						baseCorrespondence[2*ii++ + 1] = mesh2->samples[b];
						baseCorrespondence[2*ii   + 1] = mesh2->samples[c]; //currently i've mesh1.s1 - a, mesh1.s2 - b, mesh1.s3 - c and this will be permuted below in this loop, e.g., perms[1]={5,1,3} makes s1-c, s2-a, s3-b

						//refill baseCorrespPermuted according to the current reordering (one of 3! permutations)
						baseCorrespPermuted.clear();
						int idx = 0;
						for (int y = 0; y < 6; y++) //number of correspondences is 3, hence 3*2=6
							if (y % 2 == 0)
								baseCorrespPermuted.push_back(baseCorrespondence[y]); //even indices are always the mesh1 triplet
							else
								baseCorrespPermuted.push_back(baseCorrespondence[ perms3[perm][idx++] ]);	//perms3[0] = {5,3,1}, perms3[1] = {5,1,3}, ..

/*baseCorrespPermuted[0] = baseCorrespPermuted[1] = 2638;
baseCorrespPermuted[2] = baseCorrespPermuted[3] = 3;
baseCorrespPermuted[4] = baseCorrespPermuted[5] = 1298;//*/

						//////////////////////////// ICP stuff based on baseCorrespPermuted //////////////////////////////
						//center of mass of the fixed mesh2
						sum[0] = sum[1] = sum[2] = 0.0f;
						for (int i = 0; i < nP2; i++)
							for (int c1 = 0; c1 < 3; c1++)
								sum[c1] += mesh2->verts[ baseCorrespPermuted[2*i+1] ]->coords[c1]; //odd indices (2i+1) for mesh2
						for (int c1 = 0; c1 < 3; c1++)
							m2[c1] = sum[c1] / (float) nP2;

						//now that correspondences ready (in baseCorrespPermuted), i can fill ms1; actually baseCorrespPermuted[] will be permuted 3! times to handle all corresps for this pair of triplets
						//fill mean-shifted kxnP1 ms1 matrix for the 1st set (mesh1)
						for (int i = 0; i < k; i++) //for all k rows
							for (int j = 0; j < nP1; j++) //fill columns
								ms1(i, j) = verts[ baseCorrespPermuted[2*j] ]->coords[i] - m1[i]; //even indices (2j) for mesh1
						//fill mean-shifted kxnP1 ms2 matrix for the mesh2
						for (int i = 0; i < k; i++) //for all k rows
							for (int j = 0; j < nP1; j++) //fill n1 columns
								ms2(i, j) = mesh2->verts[ baseCorrespPermuted[2*j+1] ]->coords[i] - m2[i]; //odd indices (2j+1) for mesh1
						MatrixXf ms2t = ms2.transpose(); //transpose of ms2
						//kxk cross-covariance mtrx b/w mesh1 and mesh2
						cov12 = ms1 * ms2t; //k x nP1 * nP1 x k
						for (int i = 0; i < 3; i++)
							for (int j = 0; j < 3; j++)
								cov12(i, j) /= nP1;

						//Q = 4x4 complicated mtrx, see the paper
						Q(0, 0) = cov12(0, 0) + cov12(1, 1) + cov12(2, 2);
						Q(1, 0) = Q(0, 1) = cov12(1, 2) - cov12(2, 1); //(paper notation: S23 - S32, say S to cov12, and idxs of paper, i.e. start from 1)
						Q(2, 0) = Q(0, 2) = cov12(2, 0) - cov12(0, 2); //S31 - S13
						Q(3, 0) = Q(0, 3) = cov12(0, 1) - cov12(1, 0); //S12 - S21
						Q(1, 1) = 2*cov12(0, 0) - Q(0, 0);		Q(1, 2) = cov12(0, 1) + cov12(1, 0);	Q(1, 3) = cov12(0, 2) + cov12(2, 0);
						Q(2, 1) = cov12(1, 0) + cov12(0, 1);	Q(2, 2) = 2*cov12(1, 1) - Q(0, 0);		Q(2, 3) = cov12(1, 2) + cov12(2, 1);
						Q(3, 1) = cov12(2, 0) + cov12(0, 2);	Q(3, 2) = cov12(2, 1) + cov12(1, 2);	Q(3, 3) = 2*cov12(2, 2) - Q(0, 0);
						//desired rotation is decided by 1x4 quaternion vector, which is the (largest eigval's) eigvec of Q
						SelfAdjointEigenSolver<Matrix4f> eigensolver(Q); //solve eigenvalue/vector for symmetric n by n matrices, a.k.a. selfadjoint matrices
						if (eigensolver.info() != Success) abort();
						Vector4f eig_vals = eigensolver.eigenvalues(); //given in ascending order
						Matrix4f eig_vecs = eigensolver.eigenvectors(); //last column of eig_vecs corresponds to the largest eigenvalue, hence the one i want
		
						//1x4 quaternion = [q0, q1, q2, q3]
						float q0 = eig_vecs(0, 3), q1 = eig_vecs(1, 3), q2 = eig_vecs(2, 3), q3 = eig_vecs(3, 3);
						//if (q0 < 0) { q0 = -q0;	q1 = -q1;	q2 = -q2;	q3 = -q3; } //needed??????????

						//fill desired 3x3 rotation mtrx (i'm used to 4x4 mtrxs w/ coords but this 3x3 works 'cos of quaternions, i guess)
						R1[0][0] = q0*q0 + q1*q1 - q2*q2 - q3*q3;	R1[0][1] = 2*(q1*q2 - q0*q3);				R1[0][2] = 2*(q1*q3 + q0*q2);
						R1[1][0] = 2*(q1*q2 + q0*q3);				R1[1][1] = q0*q0 + q2*q2 - q1*q1 - q3*q3;	R1[1][2] = 2*(q2*q3 - q0*q1);
						R1[2][0] = 2*(q1*q3 - q0*q2);				R1[2][1] = 2*(q2*q3 + q0*q1);				R1[2][2] = q0*q0 + q3*q3 - q1*q1 - q2*q2;
						if (! adaptiveScaling) //classical ICP that doesn't bother w/ uniform scaling
						{
							//fill desired 1x3 translation: a vector from rotated/transformed mean1 to the fixed mean2 (m2); rotation not applied to the actual coords yet so this is like an uncommitted transation
							t1[0] = m2[0] - (R1[0][0]*m1[0] + R1[0][1]*m1[1] + R1[0][2]*m1[2]);
							t1[1] = m2[1] - (R1[1][0]*m1[0] + R1[1][1]*m1[1] + R1[1][2]*m1[2]);
							t1[2] = m2[2] - (R1[2][0]*m1[0] + R1[2][1]*m1[1] + R1[2][2]*m1[2]);

							//apply transformation based on this baseCorrespPermuted to all verts of the transforming mesh; even if i use triplets only in the computation of ICP transformation (samplesInUse=true), all verts are transformed here
							for (int v = 0; v < nVerts1; v++)
							{
								//first rotation then translation (first translation then rotation also works)
								//rotation
								float x = verts[v]->coords[0],
									  y = verts[v]->coords[1],
									  z = verts[v]->coords[2];
								verts[v]->coordsOriginal[0] = x; verts[v]->coordsOriginal[1] = y; verts[v]->coordsOriginal[2] = z; //roll back to these original coords for the next triplet pair
								verts[v]->coords[0] = R1[0][0]*x + R1[0][1]*y + R1[0][2]*z;
								verts[v]->coords[1] = R1[1][0]*x + R1[1][1]*y + R1[1][2]*z;
								verts[v]->coords[2] = R1[2][0]*x + R1[2][1]*y + R1[2][2]*z;
	
								//translation
								verts[v]->coords[0] += t1[0];
								verts[v]->coords[1] += t1[1];
								verts[v]->coords[2] += t1[2];
							}
						}
						else //our ICP that solves for translation and uniform scaling simulataneously to improve the initial scale guess as well
						{
							//the math of this part is explained in my paper titled Skuller; check it out
							A = B = 0.0f;
							for (int i = 0; i < 3; i++)
								C[i] = D[i] = 0.0f;
							//apply just ICP rotation of this iteration to all verts of the transforming mesh; even if i use samples[] only in the computation of ICP transformation (samplesInUse=true), all verts are transformed here
							for (int v = 0; v < nVerts1; v++)
							{
								//rotation
								float x = verts[v]->coords[0],
									  y = verts[v]->coords[1],
									  z = verts[v]->coords[2];
								verts[v]->coordsOriginal[0] = x; verts[v]->coordsOriginal[1] = y; verts[v]->coordsOriginal[2] = z; //roll back to these original coords for the next triplet pair
								verts[v]->coords[0] = R1[0][0]*x + R1[0][1]*y + R1[0][2]*z;
								verts[v]->coords[1] = R1[1][0]*x + R1[1][1]*y + R1[1][2]*z;
								verts[v]->coords[2] = R1[2][0]*x + R1[2][1]*y + R1[2][2]*z;
							}
							for (int v = 0; v < nP1; v++)
							{
								int v1 = baseCorrespPermuted[2*v], v2 = baseCorrespPermuted[2*v + 1];
								//D = [Dx Dy Dz] is computed Dx is the sum of x-coords of all matched mesh2 points, and so on (since matched mesh2 points change each iteration D is not fixed); similarly C = [Cx Cy Cz] for transformed, i.e. ICP-rotated, mesh points
								for (int i = 0; i < 3; i++)
								{
									D[i] += mesh2->verts[ v2 ]->coords[i];
									C[i] += verts[ v1 ]->coords[i];
								}
								A += verts[ v1 ]->coords[0]*verts[ v1 ]->coords[0] + verts[ v1 ]->coords[1]*verts[ v1 ]->coords[1] + verts[ v1 ]->coords[2]*verts[ v1 ]->coords[2];
								B += verts[ v1 ]->coords[0]*mesh2->verts[ v2 ]->coords[0] + verts[ v1 ]->coords[1]*mesh2->verts[ v2 ]->coords[1] + verts[ v1 ]->coords[2]*mesh2->verts[ v2 ]->coords[2];
							}
							//solve for Px = r linear system to decide x = [s t1.x t1.y t1.z] where s is the uniform scale factor, t1[] is the rotation
							Matrix4f P;
							P << A,C[0],C[1],C[2],	C[0],(float)nP1,0.0f,0.0f,	C[1],0.0f,(float)nP1,0.0f,	C[2],0.0f,0.0f,(float)nP1;
							Vector4f r;
							r << B,D[0],D[1],D[2];
							Vector4f x = P.jacobiSvd(ComputeFullU | ComputeFullV).solve(r); //s = x(0) is the uniform scale factor, and the rest is the translation t1
							//apply translation and scaling to all vertices
							for (int v = 0; v < nVerts1; v++)
							{
								//scaling
								verts[v]->coords[0] *= x(0);
								verts[v]->coords[1] *= x(0);
								verts[v]->coords[2] *= x(0);

								//translation
								verts[v]->coords[0] += x(1);
								verts[v]->coords[1] += x(2);
								verts[v]->coords[2] += x(3);
							}
						}

						//compute the new mean squared error (mse) value based on this triplet pair (in baseCorrespPermuted); squaring is efficient 'cos it removes the sqrt in distance calculation

						//check only a fraction first as in 4PCS section 2: only if a significant fraction of the point sets is well matched, test the remaining points
						bool fractionWellMatched = true;
						int fract = 5; //a small constant; make it -ve to disable this efficiency trick
#ifdef KDTREE_FOR_CLOSEST_PNTS

/* 
if (i==0) cout << pnts2[0].x[0] << " mt " << pnts2[0].x[1] << " mt " << pnts2[0].x[2] << " mtiiiiiiiiiiiiii " << endl;
		}
		kdRoot = make_tree(pnts2, nVerts2, 0, 3);

cout << pnts2[0].x[0] << " mt " << pnts2[0].x[1] << " mt " << pnts2[0].x[2] << " mt " << endl; different values printed: pnts2 updateddddddddddddddddddddddddd after maketree!!!!!!!!!!!!!!!!!!!!!!!!! */


cout << endl;
cout << 0 << ": " << mesh2->verts[0]->coords[0] << ", " << mesh2->verts[0]->coords[1] << ", " << mesh2->verts[0]->coords[2] << endl;
cout << 2057 << "mesh1: " << mesh2->verts[2057]->coords[0] << ", " << mesh2->verts[2057]->coords[1] << ", " << mesh2->verts[2057]->coords[2] << endl;
cout << 1365 << ": " << mesh2->verts[1365]->coords[0] << ", " << mesh2->verts[1365]->coords[1] << ", " << mesh2->verts[1365]->coords[2] << endl << endl;

						if (mseUsing == ALL_VERTS)
							//using a k-d tree for nVerts1 x log(nVerts2) performance instead of nVerts1 x nVerts2 of the simple exhaustive search
							for (int bv1 = 0; bv1 < nVerts1; bv1++) //for each mesh verts
							{
								struct kd_node_t testNode, * found;
								testNode.x[0] = verts[ bv1 ]->coords[0];
								testNode.x[1] = verts[ bv1 ]->coords[1];
								testNode.x[2] = verts[ bv1 ]->coords[2];
								nearest(kdRoot, &testNode, 0, 3, &found, &bestDist); //print sqrt(bestDist) as nearest() works w/ squared distances for efficiency
cout << "hhhhhhhhhhhhhhh\t";
cout << found->idx << endl;
								//mesh2->verts[found->idx]->closestVertIdx = bv1; redundant
								verts[ bv1 ]->closestVertIdx = found->idx;
								if (bv1 == fract && computeMSE(mesh2, true, fract) > SMALL)
								{
									fractionWellMatched = false;
									break;
								}
							}
						else if (mseUsing == ALL_SAMPLES)
							//using a k-d tree for nSamples1 x log(nSamples2) performance instead of nSamples1 x nSamples2 of the simple exhaustive search
							for (int bv1 = 0; bv1 < nSamples1; bv1++) //for each mesh verts
							{
								struct kd_node_t testNode, * found;
								testNode.x[0] = verts[ samples[bv1] ]->coords[0];
								testNode.x[1] = verts[ samples[bv1] ]->coords[1];
								testNode.x[2] = verts[ samples[bv1] ]->coords[2];
								nearest(kdRoot, &testNode, 0, 3, &found, &bestDist); //print sqrt(bestDist) as nearest() works w/ squared distances for efficiency
								//mesh2->verts[found->idx]->closestVertIdx = samples[bv1]; redundant
								verts[ samples[bv1] ]->closestVertIdx = found->idx;
								if (bv1 == fract && computeMSE(mesh2, false, fract) > SMALL)
								{
									fractionWellMatched = false;
									break;
								}
							}
						else //if (mseUsing == CURRENT_TRIPLET)
						{
							cout << "kd-tree doesn't make sense here 'cos triplet already in correspondence\n";
							exit(0);
						}
#else
						if (mseUsing == ALL_VERTS)
							//nVerts1 x nVerts2 for the simple exhaustive search
							for (int bv1 = 0; bv1 < nVerts1; bv1++) //for each mesh1 verts
							{
								float minDist = INF;
								for (int bv2 = 0; bv2 < nVerts2; bv2++) //for each mesh2 verts
								{
									float dist = distanceBetween2(verts[ bv1 ]->coords, mesh2->verts[ bv2 ]->coords);
									if (dist < minDist)
									{
										minDist = dist;
										verts[ bv1 ]->closestVertIdx = bv2;
									}
								}
								if (bv1 == fract && computeMSE(mesh2, true, fract) > SMALL)
								{
									fractionWellMatched = false;
									break;
								}
							}
						else if (mseUsing == ALL_SAMPLES)
							//nSamples1 x nSamples2 for the simple exhaustive search
							for (int bv1 = 0; bv1 < nSamples1; bv1++) //for each mesh1 samples
							{
								float minDist = INF;
								for (int bv2 = 0; bv2 < nSamples2; bv2++) //for each mesh2 samples
								{
									float dist = distanceBetween2(verts[ samples[bv1] ]->coords, mesh2->verts[ mesh2->samples[bv2] ]->coords);
									if (dist < minDist)
									{
										minDist = dist;
										verts[ samples[bv1] ]->closestVertIdx = mesh2->samples[bv2];
									}
								}
								if (bv1 == fract && computeMSE(mesh2, false, fract) > SMALL)
								{
									fractionWellMatched = false;
									break;
								}
							}
						else //if (mseUsing == CURRENT_TRIPLET)
						{
							//no exhaustive search at all 'cos triplet is already in correspondence
							float mse = 0.0f; //do the mean square error computation here and never in fractionWellMatched block 'cos there's no fraction to deal with (already-small-size 3x3 correspondences in use)
							for (int v = 0; v < 3; v++) //for each mesh1 and mesh2 triplet vertices
								mse += distanceBetween2(verts[ baseCorrespPermuted[2*v] ]->coords, mesh2->verts[ baseCorrespPermuted[2*v+1] ]->coords);
							mse /= 3;
							if (mse < minMSE)
							{
								minMSE = mse;
								for (int v = 0; v < nVerts1; v++)
									for (int c1 = 0; c1 < 3; c1++)
										verts[v]->coordsBest[c1] = verts[v]->coords[c1]; //remember these transformed coordinates which is currently the best w.r.t. mse
								cout << "best mse so far based on baseCorrespPermuted (" << a << ", " << b << ", " << c << ") permutation # " << perm << ": " << mse << endl;
								for (int c1 = 0; c1 < 3; c1++) cout << baseCorrespPermuted[2*c1] << " " << baseCorrespPermuted[2*c1+1] << " " << endl;
							}
							fractionWellMatched = false; //never in fractionWellMatched block 'cos there's no fraction to deal with (already-small-size 3x3 correspondences in use)
						}
#endif
						if (fractionWellMatched) //do the full mse computation only if the fraction of points are well matched
						{
							float mse = computeMSE(mesh2, mseUsing == ALL_VERTS);
//cout << computeMSE(mesh2, mseUsing == ALL_VERTS, fract) << " fraction cost vs. " << mse << " full cost\n";
							if (mse < minMSE)
							{
								minMSE = mse;
								for (int v = 0; v < nVerts1; v++)
									for (int c1 = 0; c1 < 3; c1++)
										verts[v]->coordsBest[c1] = verts[v]->coords[c1]; //remember these transformed coordinates which is currently the best w.r.t. the mse metric
								cout << "best mse so far based on baseCorrespPermuted (" << a << ", " << b << ", " << c << ") permutation # " << perm << ": " << mse << endl;
								for (int c1 = 0; c1 < 3; c1++) cout << baseCorrespPermuted[2*c1] << " " << baseCorrespPermuted[2*c1+1] << " " << endl;
							}
							nWellMatcheds++;
						}
						for (int v = 0; v < nVerts1; v++)
							for (int c1 = 0; c1 < 3; c1++)
								verts[v]->coords[c1] = verts[v]->coordsOriginal[c1]; //roll back to the original coords for the next triplet pair
					} //end of perm
					nTriplets++;
	//cout << nTriplets << "\t";
					//////////////////////////// ICP stuff based on baseCorrespPermuted ends //////////////////////////////
				} //end of triplet iters
		if (mseUsing != CURRENT_TRIPLET)
			cout << nWellMatcheds << " / " << nTriplets << " passed fraction test for mesh1 triplet " << rep+1 << "\tMin mse so far: " << minMSE << "\n";
		else
			cout << "mesh1 triplet " << rep+1 << "\tMin mse so far: " << minMSE << "\n";
	}

	//recapture memo
	for (int i = 0; i < 3; i++) delete [] R1[i]; delete [] R1;
	delete [] m1;
	delete [] m2;
	delete [] sum;
	delete [] t1;
	delete [] C;
	delete [] D;

	//transfer the best coords to v.coords to see them on screen
	for (int v = 0; v < nVerts1; v++)
		for (int c1 = 0; c1 < 3; c1++)
			verts[v]->coords[c1] = verts[v]->coordsBest[c1];
	if (minMSE == INF)
		cout << "ICP not performed due to fraction test\n";
	return minMSE;
}
float Mesh::computeMSE(Mesh* mesh2, bool mseUsingAllVerts, int fract)
{
	//computes mean squared error b/w the matching points; that is, mean of the sum of the squared distances b/w the matching points

	float mse = 0.0f;
	int s;
	if (mseUsingAllVerts)
		for (s = 0; s < (int) verts.size(); s++)
		{
			for (int i = 0; i < 3; i++)
				mse += pow(mesh2->verts[ verts[ s ]->closestVertIdx ]->coords[i] - verts[ s ]->coords[i], 2.0f);
			//mse += distanceBetween2(verts[ s ]->coords, mesh2->verts[ verts[ s ]->closestVertIdx ]->coords); does the same thing as loop just-above but w/ a micro function-call overhead
			if (s == fract)
				break; //mse based on a significant fraction of points
		}		
	else
		for (s = 0; s < (int) samples.size(); s++)
		{
			for (int i = 0; i < 3; i++)
				mse += pow(mesh2->verts[ verts[ samples[s] ]->closestVertIdx ]->coords[i] - verts[ samples[s] ]->coords[i], 2.0f);
			//mse += distanceBetween2(verts[ samples[s] ]->coords, mesh2->verts[ verts[ samples[s] ]->closestVertIdx ]->coords); does the same thing as loop just-above but w/ a micro function-call overhead
			if (s == fract)
				break; //mse based on a significant fraction of points
		}
	return mse / s;
}

void Mesh::resultToFile(char* fName)
{
	//fprints transformed mesh

	FILE* fPtrS = fopen(fName, "w");
	for (int v = 0; v < (int) verts.size(); v++)
		fprintf(fPtrS, "%f %f %f\n", verts[v]->coords[0], verts[v]->coords[1], verts[v]->coords[2]);
	fclose(fPtrS);

	cout << "\ntransformed mesh fprinted to " << fName << endl;
}
