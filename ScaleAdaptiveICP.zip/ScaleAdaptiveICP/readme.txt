This is an implementation of our paper

Scale-Adaptive ICP, Yusuf Sahillioğlu and Ladislav Kavan, Graphical Models, 2021.

Please cite this paper if using this code or paper for some purpose.

----------------------------------------------

Make sure all the inputs are in a folder named input.
Make sure there is a folder named output where I'll write the results.

Inputs are in .xyz format. Do not specifiy .xyz in the command prompt, e.g., do homer but not homer.xyz.

C:\>ScaleAdaptiveICP <cloud1-transforming> <cloud2-fixed> <ScaleAdaptive: 1 or Classical: 0> <1-to-1-start: 1 or many-to-1: 0> <nMaxIterations> <minDisplacement: optional -- default 0.001>
Sample run: C:\>ScaleAdaptiveICP homer-top-downscaled-rotated homer 1 1 200

If total displacement b/w two consecutive iteration is less than minDisplacement, then 1-to-1-start is disabled. This argument is useless when 1-to-1-start argument is 0.

Code tested on Windows, but there is no dependency (removed al visualizations to achieve that). It should work on Unix and Mac directly.

O(nlogn) k-d tree implementation is not fully tested so I currently perform O(n^2) brute force search for closest point mapping. You should enable k-d tree for significantly faster results on large inputs.

----------------------------------------------

Yusuf Sahillioğlu
